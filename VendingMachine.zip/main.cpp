// COPVending.cpp : Defines the entry point for the console application.
//

//#include "stdafx.h"
#include "Vending.h"


using namespace std;

int main()
{
	Vending Machine1;
	Machine1.machineRun();
}
