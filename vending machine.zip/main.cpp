#include "Vending.h"


using namespace std;

int main()
{
	Vending Machine1;
	Machine1.machineRun();
}
